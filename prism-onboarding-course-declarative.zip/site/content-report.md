# Content report

8 pages measured against [the content standard](https://github.com/afflom/prism-devrel/blob/main/scripts/content/standard.json) at the 360×780 compact window. 0 faults.

| Rule | Title | Faults |
|---|---|---|
| CS-01 | Every page names its reader | 0 |
| CS-02 | Every page has a plain summary | 0 |
| CS-03 | Sentences stay short | 0 |
| CS-04 | Every page shows, not only tells | 0 |
| CS-05 | Every figure has a text alternative and its data | 0 |
| CS-06 | Long blocks fold away | 0 |
| CS-07 | Technical terms are explained where they first appear | 0 |
| CS-08 | Headings tell the structure | 0 |
| CS-09 | Links say where they go | 0 |
| CS-10 | No filler words | 0 |
| CS-11 | Machines read the page too | 0 |
