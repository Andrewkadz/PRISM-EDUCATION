// The course's interactive parts. Each reads its data from a JSON script the
// generator wrote into the page, so the page and its twin say the same thing.
const KEY = 'prism-course-passed';
const passed = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { return {}; } };

for (const quiz of document.querySelectorAll('.co-quiz')) {
  const id = quiz.dataset.page;
  const qs = JSON.parse(quiz.querySelector('script[type="application/json"]').textContent);
  const picked = {};
  const total = quiz.querySelector('output.co-total');
  quiz.querySelectorAll('fieldset').forEach((fs, i) => {
    const out = fs.querySelector('output');
    fs.querySelectorAll('button').forEach((b, j) => b.addEventListener('click', () => {
      picked[i] = j;
      fs.querySelectorAll('button').forEach((x, k) => { x.setAttribute('aria-pressed', String(k === j)); x.classList.remove('co-right', 'co-wrong'); });
      b.classList.add(j === qs[i].answer ? 'co-right' : 'co-wrong');
      out.textContent = `${j === qs[i].answer ? 'Right.' : 'Not quite.'} ${qs[i].why}`;
      const score = qs.filter((q, k) => picked[k] === q.answer).length;
      if (Object.keys(picked).length === qs.length) {
        total.textContent = `${score} of ${qs.length} right.${score === qs.length ? ' This module counts as done.' : ' Change an answer to try again.'}`;
        if (score === qs.length) localStorage.setItem(KEY, JSON.stringify({ ...passed(), [id]: true }));
      }
    }));
  });
  if (passed()[id]) total.textContent = 'You have passed this quiz before.';
}

const progress = document.querySelector('output.co-progress');
if (progress) {
  const ids = JSON.parse(progress.dataset.modules);
  const done = ids.filter((m) => passed()[m]);
  progress.textContent = `Your progress: ${done.length} of ${ids.length} modules done${done.length ? ` (${done.join(', ')})` : ''}.`;
}

for (const play of document.querySelectorAll('.co-play')) {
  const spec = JSON.parse(play.querySelector('script[type="application/json"]').textContent);
  const enabled = Object.fromEntries(spec.rules.map((r) => [r.id, true]));
  const cond = (c, req) => {
    const v = req[c.field], w = c.value;
    return { is: v === w, 'is not': v !== w, '<': v < w, '<=': v <= w, '>': v > w, '>=': v >= w }[c.op] ?? false;
  };
  const parse = (text) => {
    const parts = text.trim().split(' ');
    if (parts.length !== spec.fields.length || parts.some((p) => p === '')) return null;
    const req = {};
    for (let i = 0; i < parts.length; i++) {
      const f = spec.fields[i], p = parts[i];
      if (f.kind === 'number') {
        if (!/^(0|[1-9][0-9]*)$/.test(p)) return null;
        const n = Number(p);
        if (n < f.min || n > f.max) return null;
        req[f.name] = n;
      } else {
        if (!f.values.includes(p)) return null;
        req[f.name] = p;
      }
    }
    return req;
  };
  const decide = (req) => {
    if (!req) return { answer: 'invalid', by: 'malformed' };
    for (const r of spec.rules) if (enabled[r.id] && r.when.every((c) => cond(c, req))) return { answer: r.then, by: r.id };
    return { answer: spec.otherwise, by: 'otherwise' };
  };
  const all = () => spec.fields.reduce((reqs, f) => {
    const vals = f.kind === 'number' ? Array.from({ length: f.max - f.min + 1 }, (_, i) => f.min + i) : f.values;
    return reqs.flatMap((r) => vals.map((v) => ({ ...r, [f.name]: v })));
  }, [{}]);
  const show = (req) => spec.fields.map((f) => req[f.name]).join(' ');
  const verdict = () => {
    for (const ex of spec.examples) {
      const d = decide(parse(ex.request));
      if (d.answer !== ex.response) {
        const because = d.by === 'otherwise' ? 'no rule matches (otherwise)' : `${d.by} decides it`;
        return [false, `refused: Your example \`${ex.request}\` expects ${ex.response}, but the rules answer ${d.answer}, because ${because}. Fix the example, or change the rules.`];
      }
    }
    const reqs = all();
    for (const p of spec.properties) for (const req of reqs) {
      if (!p.when.every((c) => cond(c, req))) continue;
      const d = decide(req);
      if (p.kind === 'never' ? d.answer === p.then : d.answer !== p.then) return [false, `refused: ${p.id} does not hold. The request \`${show(req)}\` meets "${p.says}", and the rules answer ${d.answer} (${d.by}). Change a rule, or restate the property.`];
    }
    return [true, `accepted: all ${spec.examples.length} examples agree with the rules, and all ${spec.properties.length} properties hold for every one of the ${reqs.length} possible requests.`];
  };
  const input = play.querySelector('input[type="text"]');
  const answer = play.querySelector('output.co-answer');
  const judged = play.querySelector('output.co-verdict');
  const update = () => {
    const d = decide(parse(input.value));
    answer.textContent = `answers ${d.answer} (${d.by === 'malformed' ? 'malformed request' : d.by === 'otherwise' ? 'no rule matched' : `${d.by} decides it`})`;
    play.querySelectorAll('tr[data-rule]').forEach((tr) => tr.classList.toggle('co-hit', tr.dataset.rule === d.by));
    const [ok, msg] = verdict();
    judged.textContent = msg;
    judged.classList.toggle('co-refused', !ok);
  };
  play.querySelectorAll('input[type="checkbox"]').forEach((box) => box.addEventListener('change', () => { enabled[box.dataset.rule] = box.checked; update(); }));
  input.addEventListener('input', update);
  play.querySelectorAll('button[data-request]').forEach((b) => b.addEventListener('click', () => { input.value = b.dataset.request; update(); }));
  update();
}
